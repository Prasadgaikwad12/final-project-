import { jsxRenderer } from 'hono/jsx-renderer'

export const renderer = jsxRenderer(({ children }) => {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>NotesCheker</title>
        <meta
          name="description"
          content="NotesCheker helps Class 11 and 12 students upload notes, use OCR text, get AI-powered scores, and see missing NCERT topics."
        />
        <link href="/static/style.css" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
})
