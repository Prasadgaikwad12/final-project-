import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { renderer } from './renderer'
import OpenAI from 'openai'

type ChapterDefinition = {
  name: string
  keywords: string[]
  mustInclude: string[]
  bonus: string[]
}

type SubjectCatalog = Record<string, ChapterDefinition[]>
type Catalog = Record<'11' | '12', SubjectCatalog>

type Bindings = {
  DB?: D1Database
  OPENAI_API_KEY?: string
  OPENAI_BASE_URL?: string
}

type StudentUser = {
  id: string
  name: string
  email: string
  password: string
  createdAt: string
}

type UploadRecord = {
  id: string
  userId: string
  fileName: string
  fileType: 'text' | 'image' | 'pdf'
  uploadedNote: string
  extractedText: string
  createdAt: string
}

type AnalysisReport = {
  summary: string
  topicIdentification: string[]
  missingConcepts: string[]
  clarityScore: number
  organizationScore: number
  readabilityScore: number
  formulaCoverageScore: number
  definitionCoverageScore: number
  missingFormulas: string[]
  missingDefinitions: string[]
  suggestions: string[]
  studyRecommendations: string[]
  strengths: string[]
  weakAreas: string[]
  misconceptions: string[]
  overallScore: number
  chapterAlignment: number
  examReadiness: number
  flashcards: { question: string; answer: string }[]
}

type NotesRecord = {
  id: string
  userId: string
  uploadedNote: string
  extractedText: string
  inputMode: 'text' | 'image' | 'pdf'
  fileName: string | null
  classLevel: '11' | '12'
  subject: string
  chapter: string
  aiAnalysisResult: AnalysisReport
  score: number
  uploadDate: string
}

const catalog: Catalog = {
  '11': {
    Physics: [
      { name: 'Physical World', keywords: ['physics', 'observation', 'laws of nature', 'theory', 'experiment'], mustInclude: ['scope of physics', 'fundamental forces'], bonus: ['technology', 'scientific method'] },
      { name: 'Units and Measurements', keywords: ['units', 'measurement', 'si units', 'errors', 'precision', 'dimensions'], mustInclude: ['si system', 'significant figures', 'dimensional analysis'], bonus: ['least count', 'random error'] },
      { name: 'Motion in a Straight Line', keywords: ['distance', 'displacement', 'velocity', 'acceleration', 'graph'], mustInclude: ['equations of motion', 'speed vs velocity'], bonus: ['free fall', 'relative motion'] },
      { name: 'Motion in a Plane', keywords: ['vectors', 'projectile', 'resolution', 'trajectory'], mustInclude: ['vector addition', 'projectile motion'], bonus: ['uniform circular motion'] },
      { name: 'Laws of Motion', keywords: ['force', 'newton', 'inertia', 'friction', 'momentum'], mustInclude: ['newtons laws', 'friction'], bonus: ['impulse', 'free body diagram'] },
      { name: 'Work Energy and Power', keywords: ['work', 'energy', 'kinetic', 'potential', 'power'], mustInclude: ['work-energy theorem', 'conservation of energy'], bonus: ['spring energy'] },
      { name: 'System of Particles and Rotational Motion', keywords: ['centre of mass', 'torque', 'angular momentum', 'moment of inertia'], mustInclude: ['torque', 'angular momentum'], bonus: ['rolling motion'] },
      { name: 'Gravitation', keywords: ['gravity', 'g', 'orbit', 'escape velocity', 'satellite'], mustInclude: ['newtons law of gravitation', 'acceleration due to gravity'], bonus: ['geostationary satellite'] },
      { name: 'Mechanical Properties of Solids', keywords: ['stress', 'strain', 'young modulus', 'elasticity'], mustInclude: ['stress strain', 'elastic modulus'], bonus: ['hookes law'] },
      { name: 'Mechanical Properties of Fluids', keywords: ['pressure', 'buoyancy', 'viscosity', 'streamline', 'surface tension'], mustInclude: ['pascals law', 'archimedes principle'], bonus: ['bernoulli theorem'] },
      { name: 'Thermal Properties of Matter', keywords: ['temperature', 'heat', 'expansion', 'specific heat', 'calorimetry'], mustInclude: ['specific heat capacity', 'thermal expansion'], bonus: ['change of state'] },
      { name: 'Thermodynamics', keywords: ['system', 'work', 'heat', 'first law', 'second law', 'entropy'], mustInclude: ['first law of thermodynamics', 'isothermal and adiabatic'], bonus: ['heat engine'] },
      { name: 'Kinetic Theory', keywords: ['molecules', 'gas', 'pressure', 'temperature', 'rms speed'], mustInclude: ['ideal gas', 'kinetic interpretation'], bonus: ['degrees of freedom'] },
      { name: 'Oscillations', keywords: ['shm', 'time period', 'frequency', 'amplitude'], mustInclude: ['simple harmonic motion', 'restoring force'], bonus: ['energy in shm'] },
      { name: 'Waves', keywords: ['wave', 'frequency', 'wavelength', 'sound', 'superposition'], mustInclude: ['wave equation', 'sound waves'], bonus: ['standing waves'] }
    ],
    Chemistry: [
      { name: 'Some Basic Concepts of Chemistry', keywords: ['mole', 'stoichiometry', 'mass', 'atoms', 'molecules'], mustInclude: ['mole concept', 'stoichiometry'], bonus: ['limiting reagent'] },
      { name: 'Structure of Atom', keywords: ['electron', 'proton', 'neutron', 'orbital', 'quantum'], mustInclude: ['bohrs model', 'quantum numbers'], bonus: ['aufbau principle'] },
      { name: 'Classification of Elements and Periodicity in Properties', keywords: ['periodic table', 'periodicity', 'atomic radius', 'ionization'], mustInclude: ['modern periodic law', 'trends'], bonus: ['electron affinity'] },
      { name: 'Chemical Bonding and Molecular Structure', keywords: ['bond', 'ionic', 'covalent', 'vsepr', 'hybridisation'], mustInclude: ['ionic and covalent bond', 'hybridisation'], bonus: ['molecular geometry'] },
      { name: 'Thermodynamics', keywords: ['enthalpy', 'entropy', 'gibbs', 'system', 'surroundings'], mustInclude: ['first law', 'enthalpy change'], bonus: ['spontaneity'] },
      { name: 'Equilibrium', keywords: ['equilibrium', 'le chatelier', 'acid', 'base', 'kc', 'kp'], mustInclude: ['chemical equilibrium', 'ionic equilibrium'], bonus: ['buffer'] },
      { name: 'Redox Reactions', keywords: ['oxidation', 'reduction', 'electron transfer', 'oxidation number'], mustInclude: ['oxidation number', 'redox balancing'], bonus: ['disproportionation'] },
      { name: 'Organic Chemistry Some Basic Principles and Techniques', keywords: ['organic', 'isomerism', 'iupac', 'reaction mechanism'], mustInclude: ['isomerism', 'purification techniques'], bonus: ['inductive effect'] },
      { name: 'Hydrocarbons', keywords: ['alkane', 'alkene', 'alkyne', 'benzene', 'aromatic'], mustInclude: ['classification of hydrocarbons', 'reactions of alkenes'], bonus: ['markovnikov rule'] }
    ],
    Mathematics: [
      { name: 'Sets', keywords: ['set', 'subset', 'union', 'intersection', 'venn'], mustInclude: ['types of sets', 'operations on sets'], bonus: ['de morgan laws'] },
      { name: 'Relations and Functions', keywords: ['relation', 'function', 'domain', 'range'], mustInclude: ['types of functions', 'domain and range'], bonus: ['composition'] },
      { name: 'Trigonometric Functions', keywords: ['sine', 'cosine', 'tangent', 'identities', 'angles'], mustInclude: ['trigonometric ratios', 'identities'], bonus: ['graphs'] },
      { name: 'Complex Numbers and Quadratic Equations', keywords: ['complex', 'imaginary', 'roots', 'quadratic'], mustInclude: ['iota', 'nature of roots'], bonus: ['argand plane'] },
      { name: 'Linear Inequalities', keywords: ['inequality', 'interval', 'solution set'], mustInclude: ['solving inequalities', 'graphical representation'], bonus: ['modulus inequality'] },
      { name: 'Permutations and Combinations', keywords: ['arrangement', 'selection', 'factorial'], mustInclude: ['permutation', 'combination'], bonus: ['circular permutation'] },
      { name: 'Binomial Theorem', keywords: ['binomial', 'expansion', 'term', 'coefficient'], mustInclude: ['general term', 'middle term'], bonus: ['approximation'] },
      { name: 'Sequence and Series', keywords: ['ap', 'gp', 'series', 'sum'], mustInclude: ['arithmetic progression', 'geometric progression'], bonus: ['sum to n terms'] },
      { name: 'Straight Lines', keywords: ['slope', 'equation', 'intercept', 'distance'], mustInclude: ['slope-intercept form', 'angle between lines'], bonus: ['distance of point from line'] },
      { name: 'Conic Sections', keywords: ['circle', 'parabola', 'ellipse', 'hyperbola'], mustInclude: ['standard equations', 'focus and directrix'], bonus: ['tangent'] },
      { name: 'Limits and Derivatives', keywords: ['limit', 'derivative', 'continuity', 'slope'], mustInclude: ['concept of limit', 'derivative as rate of change'], bonus: ['differentiability'] },
      { name: 'Statistics', keywords: ['mean', 'median', 'mode', 'variance'], mustInclude: ['measures of central tendency', 'dispersion'], bonus: ['standard deviation'] },
      { name: 'Probability', keywords: ['probability', 'event', 'sample space'], mustInclude: ['random experiment', 'basic probability formula'], bonus: ['independent events'] }
    ],
    Biology: [
      { name: 'The Living World', keywords: ['biodiversity', 'taxonomy', 'species', 'classification'], mustInclude: ['taxonomy', 'binomial nomenclature'], bonus: ['systematics'] },
      { name: 'Biological Classification', keywords: ['kingdom', 'monera', 'protista', 'fungi', 'plantae', 'animalia'], mustInclude: ['five kingdom classification', 'kingdom characteristics'], bonus: ['viruses'] },
      { name: 'Plant Kingdom', keywords: ['algae', 'bryophytes', 'pteridophytes', 'gymnosperms', 'angiosperms'], mustInclude: ['classification of plants', 'life cycles'], bonus: ['alternation of generations'] },
      { name: 'Animal Kingdom', keywords: ['porifera', 'cnidaria', 'annelida', 'arthropoda', 'chordata'], mustInclude: ['basis of classification', 'non chordates and chordates'], bonus: ['symmetry'] },
      { name: 'Morphology of Flowering Plants', keywords: ['root', 'stem', 'leaf', 'flower', 'fruit', 'seed'], mustInclude: ['modifications', 'parts of flower'], bonus: ['inflorescence'] },
      { name: 'Anatomy of Flowering Plants', keywords: ['tissue', 'xylem', 'phloem', 'epidermis', 'stomata'], mustInclude: ['tissue systems', 'internal structure'], bonus: ['secondary growth'] },
      { name: 'Structural Organisation in Animals', keywords: ['epithelial', 'connective', 'muscle', 'neural', 'earthworm', 'cockroach', 'frog'], mustInclude: ['animal tissues', 'organ systems'], bonus: ['locomotion'] },
      { name: 'Cell The Unit of Life', keywords: ['cell', 'organelle', 'membrane', 'nucleus'], mustInclude: ['cell theory', 'cell organelles'], bonus: ['prokaryotic vs eukaryotic'] },
      { name: 'Biomolecules', keywords: ['carbohydrate', 'protein', 'lipid', 'enzyme', 'nucleic acid'], mustInclude: ['types of biomolecules', 'enzymes'], bonus: ['vitamins'] },
      { name: 'Cell Cycle and Cell Division', keywords: ['mitosis', 'meiosis', 'interphase', 'chromosome'], mustInclude: ['cell cycle phases', 'mitosis and meiosis'], bonus: ['cytokinesis'] },
      { name: 'Photosynthesis in Higher Plants', keywords: ['chlorophyll', 'light reaction', 'calvin cycle', 'photosynthesis'], mustInclude: ['light reaction', 'c3 c4 pathway'], bonus: ['photorespiration'] },
      { name: 'Respiration in Plants', keywords: ['glycolysis', 'krebs cycle', 'atp', 'respiration'], mustInclude: ['aerobic and anaerobic respiration', 'electron transport'], bonus: ['fermentation'] },
      { name: 'Plant Growth and Development', keywords: ['growth', 'hormones', 'auxin', 'gibberellin'], mustInclude: ['plant growth regulators', 'phases of growth'], bonus: ['photoperiodism'] }
    ]
  },
  '12': {
    Physics: [
      { name: 'Electric Charges and Fields', keywords: ['charge', 'coulomb', 'electric field', 'flux'], mustInclude: ['coulombs law', 'electric field lines'], bonus: ['gauss law'] },
      { name: 'Electrostatic Potential and Capacitance', keywords: ['potential', 'capacitance', 'dielectric', 'equipotential'], mustInclude: ['electric potential', 'capacitor'], bonus: ['series and parallel capacitors'] },
      { name: 'Current Electricity', keywords: ['current', 'resistance', 'ohm law', 'kirchhoff'], mustInclude: ['ohms law', 'combination of resistors'], bonus: ['wheatstone bridge'] },
      { name: 'Moving Charges and Magnetism', keywords: ['magnetic field', 'lorentz force', 'biot savart', 'ampere'], mustInclude: ['force on moving charge', 'magnetic field due to current'], bonus: ['cyclotron'] },
      { name: 'Magnetism and Matter', keywords: ['magnet', 'dipole', 'earth magnetism'], mustInclude: ['bar magnet', 'magnetic properties'], bonus: ['dia para ferro'] },
      { name: 'Electromagnetic Induction', keywords: ['induction', 'faraday', 'lenz', 'flux'], mustInclude: ['faradays law', 'lenzs law'], bonus: ['eddy currents'] },
      { name: 'Alternating Current', keywords: ['ac', 'rms', 'reactance', 'transformer'], mustInclude: ['ac voltage current', 'transformer'], bonus: ['power factor'] },
      { name: 'Electromagnetic Waves', keywords: ['em waves', 'spectrum', 'transverse'], mustInclude: ['properties of em waves', 'electromagnetic spectrum'], bonus: ['applications'] },
      { name: 'Ray Optics and Optical Instruments', keywords: ['reflection', 'refraction', 'lens', 'mirror', 'microscope'], mustInclude: ['mirror formula', 'lens formula'], bonus: ['optical instruments'] },
      { name: 'Wave Optics', keywords: ['interference', 'diffraction', 'polarisation'], mustInclude: ['young double slit experiment', 'diffraction'], bonus: ['polarisation'] },
      { name: 'Dual Nature of Radiation and Matter', keywords: ['photoelectric', 'de broglie', 'photon'], mustInclude: ['photoelectric effect', 'matter waves'], bonus: ['work function'] },
      { name: 'Atoms', keywords: ['bohr', 'spectra', 'hydrogen atom'], mustInclude: ['bohr model', 'line spectra'], bonus: ['energy levels'] },
      { name: 'Nuclei', keywords: ['nucleus', 'radioactivity', 'fission', 'fusion'], mustInclude: ['nuclear composition', 'radioactive decay'], bonus: ['binding energy'] },
      { name: 'Semiconductor Electronics', keywords: ['semiconductor', 'diode', 'transistor', 'logic gate'], mustInclude: ['p n junction', 'transistor basics'], bonus: ['logic gates'] }
    ],
    Chemistry: [
      { name: 'Solutions', keywords: ['solution', 'concentration', 'molarity', 'henry law'], mustInclude: ['types of solutions', 'colligative properties'], bonus: ['abnormal molar mass'] },
      { name: 'Electrochemistry', keywords: ['electrode', 'cell', 'emf', 'electrolysis', 'nernst'], mustInclude: ['galvanic cell', 'nernst equation'], bonus: ['conductance'] },
      { name: 'Chemical Kinetics', keywords: ['rate', 'order', 'molecularity', 'half life'], mustInclude: ['rate law', 'factors affecting rate'], bonus: ['arrhenius equation'] },
      { name: 'd and f Block Elements', keywords: ['transition', 'lanthanoids', 'actinoids'], mustInclude: ['properties of d block', 'lanthanoid contraction'], bonus: ['oxidation states'] },
      { name: 'Coordination Compounds', keywords: ['ligand', 'coordination number', 'isomerism'], mustInclude: ['werner theory', 'nomenclature'], bonus: ['crystal field theory'] },
      { name: 'Haloalkanes and Haloarenes', keywords: ['haloalkane', 'haloarene', 'nucleophilic substitution'], mustInclude: ['preparation', 'substitution reactions'], bonus: ['finkelstein reaction'] },
      { name: 'Alcohols Phenols and Ethers', keywords: ['alcohol', 'phenol', 'ether', 'hydroxyl'], mustInclude: ['classification', 'important reactions'], bonus: ['acidity of phenol'] },
      { name: 'Aldehydes Ketones and Carboxylic Acids', keywords: ['aldehyde', 'ketone', 'carboxylic acid', 'carbonyl'], mustInclude: ['preparation', 'reactions of carbonyl compounds'], bonus: ['aldol condensation'] },
      { name: 'Amines', keywords: ['amine', 'basicity', 'diazonium salt'], mustInclude: ['classification of amines', 'preparation and reactions'], bonus: ['carbylamine test'] },
      { name: 'Biomolecules', keywords: ['carbohydrates', 'proteins', 'vitamins', 'dna'], mustInclude: ['monosaccharides proteins nucleic acids', 'biological roles'], bonus: ['enzymes'] }
    ],
    Mathematics: [
      { name: 'Relations and Functions', keywords: ['relation', 'function', 'domain', 'range'], mustInclude: ['types of functions', 'binary operations'], bonus: ['composition'] },
      { name: 'Inverse Trigonometric Functions', keywords: ['inverse trig', 'principal value'], mustInclude: ['domain and range of inverse functions', 'identities'], bonus: ['graphs'] },
      { name: 'Matrices', keywords: ['matrix', 'order', 'transpose', 'determinant'], mustInclude: ['types of matrices', 'operations'], bonus: ['symmetric matrix'] },
      { name: 'Determinants', keywords: ['determinant', 'minor', 'cofactor'], mustInclude: ['properties of determinants', 'area using determinants'], bonus: ['adjoint'] },
      { name: 'Continuity and Differentiability', keywords: ['continuity', 'differentiatility', 'derivative'], mustInclude: ['conditions of continuity', 'rules of differentiation'], bonus: ['chain rule'] },
      { name: 'Application of Derivatives', keywords: ['increasing', 'decreasing', 'maxima', 'minima', 'tangent'], mustInclude: ['monotonicity', 'maxima and minima'], bonus: ['approximation'] },
      { name: 'Integrals', keywords: ['integration', 'antiderivative', 'substitution'], mustInclude: ['methods of integration', 'basic formulas'], bonus: ['partial fractions'] },
      { name: 'Application of Integrals', keywords: ['area', 'curve', 'region'], mustInclude: ['area under curves', 'bounded region'], bonus: ['between two curves'] },
      { name: 'Differential Equations', keywords: ['differential equation', 'solution', 'order', 'degree'], mustInclude: ['formation', 'general and particular solution'], bonus: ['variable separable'] },
      { name: 'Vector Algebra', keywords: ['vector', 'dot product', 'cross product'], mustInclude: ['types of vectors', 'scalar and vector product'], bonus: ['projection'] },
      { name: 'Three Dimensional Geometry', keywords: ['line', 'plane', 'distance', 'direction ratios'], mustInclude: ['equation of line', 'equation of plane'], bonus: ['shortest distance'] },
      { name: 'Linear Programming', keywords: ['constraints', 'objective function', 'feasible region'], mustInclude: ['formulation', 'graphical method'], bonus: ['corner point method'] },
      { name: 'Probability', keywords: ['conditional probability', 'bayes theorem', 'independence'], mustInclude: ['conditional probability', 'bayes theorem'], bonus: ['random variable'] }
    ],
    Biology: [
      { name: 'Reproduction in Organisms', keywords: ['reproduction', 'asexual', 'sexual', 'life span'], mustInclude: ['modes of reproduction', 'significance'], bonus: ['vegetative propagation'] },
      { name: 'Sexual Reproduction in Flowering Plants', keywords: ['flower', 'pollination', 'fertilisation', 'embryo sac'], mustInclude: ['microsporogenesis', 'double fertilisation'], bonus: ['seed formation'] },
      { name: 'Human Reproduction', keywords: ['male reproductive system', 'female reproductive system', 'gamete', 'fertilisation'], mustInclude: ['reproductive organs', 'menstrual cycle'], bonus: ['pregnancy'] },
      { name: 'Reproductive Health', keywords: ['contraception', 'std', 'infertility', 'ivf'], mustInclude: ['birth control methods', 'sexually transmitted infections'], bonus: ['assisted reproductive technologies'] },
      { name: 'Principles of Inheritance and Variation', keywords: ['mendel', 'gene', 'allele', 'inheritance'], mustInclude: ['mendels laws', 'monohybrid and dihybrid cross'], bonus: ['pedigree'] },
      { name: 'Molecular Basis of Inheritance', keywords: ['dna', 'rna', 'replication', 'transcription', 'translation'], mustInclude: ['structure of dna', 'central dogma'], bonus: ['genetic code'] },
      { name: 'Evolution', keywords: ['evolution', 'darwin', 'selection', 'speciation'], mustInclude: ['evidence of evolution', 'natural selection'], bonus: ['hardy weinberg'] },
      { name: 'Human Health and Disease', keywords: ['disease', 'pathogen', 'immunity', 'vaccination'], mustInclude: ['innate and acquired immunity', 'common diseases'], bonus: ['aids cancer'] },
      { name: 'Strategies for Enhancement in Food Production', keywords: ['animal husbandry', 'plant breeding', 'single cell protein'], mustInclude: ['crop improvement', 'animal breeding'], bonus: ['biofortification'] },
      { name: 'Microbes in Human Welfare', keywords: ['microbes', 'fermentation', 'biogas', 'antibiotics'], mustInclude: ['microbes in industry', 'sewage treatment'], bonus: ['biocontrol'] },
      { name: 'Biotechnology Principles and Processes', keywords: ['biotechnology', 'restriction enzyme', 'vector', 'pcr'], mustInclude: ['genetic engineering tools', 'processes'], bonus: ['bioreactor'] },
      { name: 'Biotechnology and its Applications', keywords: ['gmo', 'gene therapy', 'insulin', 'transgenic'], mustInclude: ['applications in medicine and agriculture', 'ethical issues'], bonus: ['rna interference'] },
      { name: 'Organisms and Populations', keywords: ['population', 'adaptation', 'niche', 'ecology'], mustInclude: ['population attributes', 'interactions'], bonus: ['growth models'] },
      { name: 'Ecosystem', keywords: ['ecosystem', 'food chain', 'productivity', 'decomposition'], mustInclude: ['components of ecosystem', 'energy flow'], bonus: ['ecological pyramids'] },
      { name: 'Biodiversity and Conservation', keywords: ['biodiversity', 'conservation', 'hotspots', 'extinction'], mustInclude: ['levels of biodiversity', 'conservation methods'], bonus: ['in situ ex situ'] }
    ]
  }
}

const inMemoryUsers: StudentUser[] = []
const inMemoryUploads: UploadRecord[] = []
const inMemoryNotes: NotesRecord[] = []
const inMemorySessions = new Map<string, string>()

const normalize = (text: string) => text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ')
const sentenceCount = (text: string) => text.split(/[.!?\n]+/).map((item) => item.trim()).filter(Boolean).length
const makeId = (prefix: string) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const parseCookies = (cookieHeader?: string | null) => {
  const pairs = (cookieHeader || '').split(';').map((part) => part.trim()).filter(Boolean)
  return Object.fromEntries(
    pairs.map((pair) => {
      const separator = pair.indexOf('=')
      if (separator === -1) return [pair, '']
      return [pair.slice(0, separator), decodeURIComponent(pair.slice(separator + 1))]
    })
  )
}

const createSessionCookie = (token: string) => `notescheker_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800`
const clearSessionCookie = 'notescheker_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'

const countMatches = (notes: string, terms: string[]) => {
  const text = normalize(notes)
  return terms.filter((term) => text.includes(normalize(term))).length
}

const pickWeakAreas = (missingConcepts: string[], missingDefinitions: string[], missingFormulas: string[]) => {
  return [...missingConcepts, ...missingDefinitions, ...missingFormulas].slice(0, 6)
}

async function getAuthenticatedUser(c: Parameters<typeof app.get>[1] extends never ? never : any) {
  const cookies = parseCookies(c.req.header('Cookie'))
  const token = cookies.notescheker_session
  if (!token) return null

  const userId = inMemorySessions.get(token)
  if (!userId) return null

  if (c.env.DB) {
    await ensureTables(c.env.DB)
    const user = await c.env.DB.prepare(`SELECT id, name, email, password, created_at FROM students WHERE id = ?`).bind(userId).first<any>()
    if (!user) return null
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      password: user.password,
      createdAt: user.created_at,
    } satisfies StudentUser
  }

  return inMemoryUsers.find((user) => user.id === userId) || null
}

async function getAiDeepAnalysis(notes: string, chapterInfo: ChapterDefinition, subject: string, classLevel: string, env?: Bindings): Promise<Partial<AnalysisReport> | null> {
  try {
    const apiKey = env?.OPENAI_API_KEY || globalThis.process?.env?.OPENAI_API_KEY
    const baseURL = env?.OPENAI_BASE_URL || globalThis.process?.env?.OPENAI_BASE_URL
    if (!apiKey || !baseURL) return null

    const client = new OpenAI({ apiKey, baseURL })
    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content:
            'You are an expert NCERT note analysis assistant. Return strict JSON with keys: summary, topicIdentification, missingConcepts, clarityScore, organizationScore, readabilityScore, formulaCoverageScore, definitionCoverageScore, missingFormulas, missingDefinitions, suggestions, studyRecommendations, strengths, weakAreas, misconceptions, overallScore, chapterAlignment, examReadiness, flashcards.'
        },
        {
          role: 'user',
          content: JSON.stringify({
            classLevel,
            subject,
            chapter: chapterInfo.name,
            mustInclude: chapterInfo.mustInclude,
            keywords: chapterInfo.keywords,
            bonus: chapterInfo.bonus,
            notes,
          })
        }
      ],
      response_format: { type: 'json_object' }
    })

    const content = completion.choices[0]?.message?.content
    if (!content) return null
    return JSON.parse(content)
  } catch {
    return null
  }
}

async function extractContentText(input: { inputMode: 'text' | 'image' | 'pdf'; rawContent: string; env?: Bindings }) {
  if (input.inputMode === 'text') {
    return input.rawContent.trim()
  }

  if (input.inputMode === 'image' || input.inputMode === 'pdf') {
    const apiKey = input.env?.OPENAI_API_KEY || globalThis.process?.env?.OPENAI_API_KEY
    const baseURL = input.env?.OPENAI_BASE_URL || globalThis.process?.env?.OPENAI_BASE_URL

    if (!apiKey || !baseURL) {
      return input.inputMode === 'pdf'
        ? 'PDF upload captured. Real PDF text extraction will work after AI/OCR credentials are connected.'
        : 'Image upload captured. Real OCR extraction will work after AI/OCR credentials are connected.'
    }

    const client = new OpenAI({ apiKey, baseURL })
    const prompt = input.inputMode === 'pdf'
      ? 'You are a PDF notes extractor. Extract clean study notes text from this uploaded PDF content representation and return plain text only.'
      : 'You are an OCR notes extractor. Extract clean handwritten or printed study notes text from this uploaded image and return plain text only.'

    const contentBlocks = input.inputMode === 'image'
      ? [
          { type: 'text' as const, text: prompt },
          { type: 'image_url' as const, image_url: { url: input.rawContent } }
        ]
      : [
          { type: 'text' as const, text: `${prompt}\n\nFile payload:\n${input.rawContent.slice(0, 120000)}` }
        ]

    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'user', content: contentBlocks }
      ]
    })

    return completion.choices[0]?.message?.content?.trim() || ''
  }

  return ''
}

function clampScore(value: number) {
  if (Number.isNaN(value)) return 0
  return Math.max(0, Math.min(100, Math.round(value)))
}

async function analyseNotes(input: {
  userId: string
  classLevel: '11' | '12'
  subject: string
  chapter: string
  uploadedNote: string
  extractedText: string
  inputMode: 'text' | 'image' | 'pdf'
  fileName: string | null
  env?: Bindings
}): Promise<NotesRecord> {
  const chapterInfo = catalog[input.classLevel][input.subject]?.find((item) => item.name === input.chapter)
  if (!chapterInfo) {
    throw new Error('Selected chapter was not found in the NCERT catalog.')
  }

  const notes = input.extractedText.trim()
  const words = notes.split(/\s+/).filter(Boolean)
  const wordCount = words.length
  const keywordHits = countMatches(notes, chapterInfo.keywords)
  const mustHits = countMatches(notes, chapterInfo.mustInclude)
  const bonusHits = countMatches(notes, chapterInfo.bonus)
  const totalImportant = Math.max(chapterInfo.keywords.length + chapterInfo.mustInclude.length, 1)
  const chapterAlignment = clampScore(((keywordHits + mustHits) / totalImportant) * 100)
  const clarityScore = clampScore((sentenceCount(notes) / 9) * 100)
  const organizationScore = clampScore(((notes.match(/\n/g)?.length || 0) + (notes.match(/[:\-•]/g)?.length || 0)) * 8)
  const readabilityScore = clampScore((Math.min(wordCount, 320) / 320) * 100)
  const formulaTargets = chapterInfo.mustInclude.filter((item) => /law|equation|formula|theorem|rule|cycle/i.test(item))
  const formulaCoverageScore = clampScore((countMatches(notes, formulaTargets) / Math.max(formulaTargets.length, 1)) * 100)
  const definitionCoverageScore = clampScore((mustHits / Math.max(chapterInfo.mustInclude.length, 1)) * 100)
  const missingConcepts = chapterInfo.mustInclude.filter((topic) => !normalize(notes).includes(normalize(topic)))
  const missingDefinitions = chapterInfo.mustInclude.filter((topic) => !normalize(notes).includes(normalize(topic))).slice(0, 5)
  const missingFormulas = chapterInfo.bonus.filter((topic) => /law|equation|formula|theorem|rule|cycle/i.test(topic) && !normalize(notes).includes(normalize(topic))).slice(0, 4)
  const strengths = [
    chapterAlignment >= 65 ? 'Your notes are aligned with major NCERT chapter keywords.' : 'You covered some important chapter terms and can build from here.',
    clarityScore >= 60 ? 'Your explanations are readable and student-friendly.' : 'You can improve clarity using shorter points and cleaner phrasing.',
    organizationScore >= 55 ? 'Your note structure helps quick revision.' : 'Add headings, bullet points, and definition blocks for better structure.'
  ]
  const suggestions = [
    missingConcepts.length ? `Add these missing concepts: ${missingConcepts.slice(0, 4).join(', ')}.` : 'Add one more worked example or diagram explanation for mastery.',
    'Write one-line definitions for all major terms in the chapter.',
    `Revise ${input.subject} board-style questions from ${input.chapter}.`
  ]
  const studyRecommendations = [
    'Revise the NCERT summary before sleeping for spaced repetition.',
    'Turn the missing concepts into flashcards and test yourself tomorrow.',
    'Solve 5 past-paper questions from the same chapter and compare with your notes.'
  ]
  const weakAreas = pickWeakAreas(missingConcepts, missingDefinitions, missingFormulas)
  const misconceptions = missingConcepts.length
    ? [`Your notes may create confusion around ${missingConcepts[0]}. Add a precise textbook definition.`]
    : ['No strong misconception detected from the current notes.']

  let report: AnalysisReport = {
    summary: `These notes on ${input.chapter} show ${chapterAlignment >= 70 ? 'good' : 'partial'} coverage of the NCERT chapter. Focus more on missing concepts and stronger organization to improve exam performance.`,
    topicIdentification: chapterInfo.keywords.slice(0, 6),
    missingConcepts,
    clarityScore,
    organizationScore,
    readabilityScore,
    formulaCoverageScore,
    definitionCoverageScore,
    missingFormulas,
    missingDefinitions,
    suggestions,
    studyRecommendations,
    strengths,
    weakAreas,
    misconceptions,
    overallScore: clampScore(chapterAlignment * 0.34 + clarityScore * 0.16 + organizationScore * 0.14 + readabilityScore * 0.12 + formulaCoverageScore * 0.12 + definitionCoverageScore * 0.12 + Math.min(bonusHits * 3, 8)),
    chapterAlignment,
    examReadiness: clampScore(chapterAlignment * 0.6 + clarityScore * 0.2 + organizationScore * 0.2),
    flashcards: chapterInfo.mustInclude.slice(0, 4).map((topic) => ({
      question: `What is ${topic}?`,
      answer: `Write the NCERT definition and one exam-ready point for ${topic}.`
    }))
  }

  const aiData = await getAiDeepAnalysis(notes, chapterInfo, input.subject, input.classLevel, input.env)
  if (aiData) {
    report = {
      ...report,
      ...aiData,
      clarityScore: clampScore(Number(aiData.clarityScore ?? report.clarityScore)),
      organizationScore: clampScore(Number(aiData.organizationScore ?? report.organizationScore)),
      readabilityScore: clampScore(Number(aiData.readabilityScore ?? report.readabilityScore)),
      formulaCoverageScore: clampScore(Number(aiData.formulaCoverageScore ?? report.formulaCoverageScore)),
      definitionCoverageScore: clampScore(Number(aiData.definitionCoverageScore ?? report.definitionCoverageScore)),
      overallScore: clampScore(Number(aiData.overallScore ?? report.overallScore)),
      chapterAlignment: clampScore(Number(aiData.chapterAlignment ?? report.chapterAlignment)),
      examReadiness: clampScore(Number(aiData.examReadiness ?? report.examReadiness)),
      topicIdentification: Array.isArray(aiData.topicIdentification) ? aiData.topicIdentification : report.topicIdentification,
      missingConcepts: Array.isArray(aiData.missingConcepts) ? aiData.missingConcepts : report.missingConcepts,
      missingFormulas: Array.isArray(aiData.missingFormulas) ? aiData.missingFormulas : report.missingFormulas,
      missingDefinitions: Array.isArray(aiData.missingDefinitions) ? aiData.missingDefinitions : report.missingDefinitions,
      suggestions: Array.isArray(aiData.suggestions) ? aiData.suggestions : report.suggestions,
      studyRecommendations: Array.isArray(aiData.studyRecommendations) ? aiData.studyRecommendations : report.studyRecommendations,
      strengths: Array.isArray(aiData.strengths) ? aiData.strengths : report.strengths,
      weakAreas: Array.isArray(aiData.weakAreas) ? aiData.weakAreas : report.weakAreas,
      misconceptions: Array.isArray(aiData.misconceptions) ? aiData.misconceptions : report.misconceptions,
      flashcards: Array.isArray(aiData.flashcards) ? aiData.flashcards : report.flashcards,
      summary: typeof aiData.summary === 'string' && aiData.summary.trim() ? aiData.summary : report.summary,
    }
  }

  return {
    id: makeId('note'),
    userId: input.userId,
    uploadedNote: input.uploadedNote,
    extractedText: input.extractedText,
    inputMode: input.inputMode,
    fileName: input.fileName,
    classLevel: input.classLevel,
    subject: input.subject,
    chapter: input.chapter,
    aiAnalysisResult: report,
    score: report.overallScore,
    uploadDate: new Date().toISOString()
  }
}

async function ensureTables(db: D1Database) {
  await db.prepare(`
    CREATE TABLE IF NOT EXISTS students (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
  `).run()

  await db.prepare(`
    CREATE TABLE IF NOT EXISTS uploads (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_type TEXT NOT NULL,
      uploaded_note TEXT NOT NULL,
      extracted_text TEXT NOT NULL,
      created_at TEXT NOT NULL
    )
  `).run()

  await db.prepare(`
    CREATE TABLE IF NOT EXISTS notes_analysis (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      uploaded_note TEXT NOT NULL,
      extracted_text TEXT NOT NULL,
      input_mode TEXT NOT NULL,
      file_name TEXT,
      class_level TEXT NOT NULL,
      subject TEXT NOT NULL,
      chapter TEXT NOT NULL,
      ai_analysis_result TEXT NOT NULL,
      score INTEGER NOT NULL,
      upload_date TEXT NOT NULL
    )
  `).run()
}

const app = new Hono<{ Bindings: Bindings }>()
app.use('*', cors())
app.use(renderer)

app.get('/api/catalog', (c) => c.json({ catalog }))
app.get('/api/chapters', (c) => {
  const classLevel = c.req.query('classLevel') as '11' | '12'
  const subject = c.req.query('subject')
  if (!classLevel || !subject || !catalog[classLevel]?.[subject]) {
    return c.json({ chapters: [] })
  }
  return c.json({ chapters: catalog[classLevel][subject] })
})

app.get('/api/auth/me', async (c) => {
  const user = await getAuthenticatedUser(c)
  if (!user) return c.json({ user: null })
  return c.json({ user: { id: user.id, name: user.name, email: user.email } })
})

app.post('/api/auth/register', async (c) => {
  const body = await c.req.json()
  const name = String(body.name || '').trim()
  const email = String(body.email || '').trim().toLowerCase()
  const password = String(body.password || '').trim()
  const confirmPassword = String(body.confirmPassword || '').trim()

  if (!name || !email || !password || !confirmPassword) {
    return c.json({ error: 'Name, email, password and confirm password are required.' }, 400)
  }
  if (password !== confirmPassword) {
    return c.json({ error: 'Password and confirm password do not match.' }, 400)
  }

  const user: StudentUser = {
    id: makeId('user'),
    name,
    email,
    password,
    createdAt: new Date().toISOString()
  }

  if (c.env.DB) {
    await ensureTables(c.env.DB)
    const existing = await c.env.DB.prepare(`SELECT id FROM students WHERE email = ?`).bind(email).first()
    if (existing) return c.json({ error: 'Email already registered.' }, 400)
    await c.env.DB.prepare(`INSERT INTO students (id, name, email, password, created_at) VALUES (?, ?, ?, ?, ?)`).bind(user.id, user.name, user.email, user.password, user.createdAt).run()
  } else {
    if (inMemoryUsers.some((item) => item.email === email)) return c.json({ error: 'Email already registered.' }, 400)
    inMemoryUsers.push(user)
  }

  return c.json({ success: true })
})

app.post('/api/auth/login', async (c) => {
  const body = await c.req.json()
  const email = String(body.email || '').trim().toLowerCase()
  const password = String(body.password || '').trim()

  let user: StudentUser | null = null
  if (c.env.DB) {
    await ensureTables(c.env.DB)
    const row = await c.env.DB.prepare(`SELECT id, name, email, password, created_at FROM students WHERE email = ? AND password = ?`).bind(email, password).first<any>()
    if (row) {
      user = { id: row.id, name: row.name, email: row.email, password: row.password, createdAt: row.created_at }
    }
  } else {
    user = inMemoryUsers.find((item) => item.email === email && item.password === password) || null
  }

  if (!user) return c.json({ error: 'Invalid email or password.' }, 401)

  const token = makeId('session')
  inMemorySessions.set(token, user.id)
  c.header('Set-Cookie', createSessionCookie(token))
  return c.json({ user: { id: user.id, name: user.name, email: user.email } })
})

app.post('/api/auth/logout', async (c) => {
  const cookies = parseCookies(c.req.header('Cookie'))
  if (cookies.notescheker_session) inMemorySessions.delete(cookies.notescheker_session)
  c.header('Set-Cookie', clearSessionCookie)
  return c.json({ success: true })
})

app.get('/api/results', async (c) => {
  const user = await getAuthenticatedUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)

  const sortBy = c.req.query('sortBy') || 'date'
  let records: NotesRecord[] = []

  if (c.env.DB) {
    await ensureTables(c.env.DB)
    const rows = await c.env.DB.prepare(`SELECT * FROM notes_analysis WHERE user_id = ?`).bind(user.id).all<any>()
    records = (rows.results || []).map((row: any) => ({
      id: row.id,
      userId: row.user_id,
      uploadedNote: row.uploaded_note,
      extractedText: row.extracted_text,
      inputMode: row.input_mode,
      fileName: row.file_name,
      classLevel: row.class_level,
      subject: row.subject,
      chapter: row.chapter,
      aiAnalysisResult: JSON.parse(row.ai_analysis_result),
      score: row.score,
      uploadDate: row.upload_date,
    }))
  } else {
    records = inMemoryNotes.filter((item) => item.userId === user.id)
  }

  records.sort((a, b) => sortBy === 'score' ? b.score - a.score : new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
  return c.json({ results: records })
})

app.get('/api/results/:id', async (c) => {
  const user = await getAuthenticatedUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)

  const id = c.req.param('id')
  let record: NotesRecord | undefined

  if (c.env.DB) {
    await ensureTables(c.env.DB)
    const row = await c.env.DB.prepare(`SELECT * FROM notes_analysis WHERE id = ? AND user_id = ?`).bind(id, user.id).first<any>()
    if (row) {
      record = {
        id: row.id,
        userId: row.user_id,
        uploadedNote: row.uploaded_note,
        extractedText: row.extracted_text,
        inputMode: row.input_mode,
        fileName: row.file_name,
        classLevel: row.class_level,
        subject: row.subject,
        chapter: row.chapter,
        aiAnalysisResult: JSON.parse(row.ai_analysis_result),
        score: row.score,
        uploadDate: row.upload_date,
      }
    }
  } else {
    record = inMemoryNotes.find((item) => item.id === id && item.userId === user.id)
  }

  if (!record) return c.json({ error: 'Report not found.' }, 404)
  return c.json({ report: record })
})

app.post('/api/analyze', async (c) => {
  const user = await getAuthenticatedUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)

  const body = await c.req.json()
  const classLevel = String(body.classLevel || '').trim() as '11' | '12'
  const subject = String(body.subject || '').trim()
  const chapter = String(body.chapter || '').trim()
  const inputMode = String(body.inputMode || '').trim() as 'text' | 'image' | 'pdf'
  const notesText = String(body.notesText || '').trim()
  const uploadDataUrl = String(body.uploadDataUrl || '').trim()
  const fileName = body.fileName ? String(body.fileName) : null

  if (!classLevel || !subject || !chapter || !inputMode) {
    return c.json({ error: 'Class, subject, chapter and input mode are required.' }, 400)
  }

  if (inputMode === 'text' && !notesText) {
    return c.json({ error: 'Please enter your notes text.' }, 400)
  }
  if ((inputMode === 'image' || inputMode === 'pdf') && !uploadDataUrl) {
    return c.json({ error: 'Please upload exactly one file.' }, 400)
  }

  const rawContent = inputMode === 'text' ? notesText : uploadDataUrl
  const extractedText = await extractContentText({ inputMode, rawContent, env: c.env })
  const uploadedNote = rawContent

  if (!extractedText) {
    return c.json({ error: 'Could not extract readable text from the uploaded content.' }, 400)
  }

  if (inputMode !== 'text') {
    const upload: UploadRecord = {
      id: makeId('upload'),
      userId: user.id,
      fileName: fileName || `uploaded-${inputMode}`,
      fileType: inputMode,
      uploadedNote,
      extractedText,
      createdAt: new Date().toISOString(),
    }

    if (c.env.DB) {
      await ensureTables(c.env.DB)
      await c.env.DB.prepare(`INSERT INTO uploads (id, user_id, file_name, file_type, uploaded_note, extracted_text, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(upload.id, upload.userId, upload.fileName, upload.fileType, upload.uploadedNote, upload.extractedText, upload.createdAt).run()
    } else {
      inMemoryUploads.push(upload)
    }
  }

  const analysis = await analyseNotes({
    userId: user.id,
    classLevel,
    subject,
    chapter,
    uploadedNote,
    extractedText,
    inputMode,
    fileName,
    env: c.env,
  })

  if (c.env.DB) {
    await ensureTables(c.env.DB)
    await c.env.DB.prepare(`INSERT INTO notes_analysis (id, user_id, uploaded_note, extracted_text, input_mode, file_name, class_level, subject, chapter, ai_analysis_result, score, upload_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
      analysis.id,
      analysis.userId,
      analysis.uploadedNote,
      analysis.extractedText,
      analysis.inputMode,
      analysis.fileName,
      analysis.classLevel,
      analysis.subject,
      analysis.chapter,
      JSON.stringify(analysis.aiAnalysisResult),
      analysis.score,
      analysis.uploadDate,
    ).run()
  } else {
    inMemoryNotes.push(analysis)
  }

  return c.json({ analysis, aiConnected: Boolean((c.env.OPENAI_API_KEY || globalThis.process?.env?.OPENAI_API_KEY) && (c.env.OPENAI_BASE_URL || globalThis.process?.env?.OPENAI_BASE_URL)) })
})

app.get('/', (c) => c.render(
  <main class="app-shell">
    <div class="floating-orb orb-one"></div>
    <div class="floating-orb orb-two"></div>
    <button id="theme-toggle" class="theme-icon-button" type="button" aria-label="Toggle theme">☀️</button>

    <section id="login-view" class="view active-view">
      <div class="auth-layout reveal-up">
        <div class="card auth-brand-panel">
          <div class="mini-nav">
            <a href="#home-section">Home</a>
            <a href="#features-section">Features</a>
            <a href="#how-section">How It Works</a>
          </div>
          <div id="home-section">
            <p class="eyebrow">AI Notes Analysis Platform</p>
            <h1>NotesChecker</h1>
            <p class="lead">Login first, then analyze your notes in a private dashboard. You can use one thing at a time: text, image, or PDF. The app extracts text and prepares a detailed AI-ready study report.</p>
            <div class="hero-badges">
              <span>Single input mode</span>
              <span>Text / Image / PDF</span>
              <span>Private student dashboard</span>
              <span>NCERT-focused analysis</span>
            </div>
          </div>
          <div id="features-section" class="feature-stack">
            <div class="card-lite"><strong>Detailed report</strong><p class="muted">Topic detection, missing concepts, readability, formulas, definitions, suggestions, and score.</p></div>
            <div class="card-lite"><strong>One upload only</strong><p class="muted">Choose either text, image, or PDF at one time for a cleaner student flow.</p></div>
            <div class="card-lite"><strong>Private history</strong><p class="muted">Every logged-in student gets their own report history dashboard.</p></div>
          </div>
          <div id="how-section" class="how-list">
            <div><strong>1.</strong> Register or login</div>
            <div><strong>2.</strong> Upload text/image/PDF</div>
            <div><strong>3.</strong> Get AI-based study analysis</div>
            <div><strong>4.</strong> Review history on dashboard</div>
          </div>
        </div>

        <div class="card auth-form-panel reveal-scale">
          <div class="auth-tabs">
            <button id="show-login" class="tab-button active-tab" type="button">Login</button>
            <button id="show-register" class="tab-button" type="button">Create Account</button>
          </div>
          <form id="login-form" class="auth-form active-auth-form">
            <label><span>Email</span><input type="email" name="email" required /></label>
            <label><span>Password</span><input type="password" name="password" required /></label>
            <button type="submit">Login to NotesChecker</button>
            <p class="hint" id="auth-feedback">Enter your email and password to continue.</p>
          </form>
          <form id="register-form" class="auth-form hidden">
            <label><span>Name</span><input type="text" name="name" required /></label>
            <label><span>Email</span><input type="email" name="email" required /></label>
            <label><span>Password</span><input type="password" name="password" required /></label>
            <label><span>Confirm Password</span><input type="password" name="confirmPassword" required /></label>
            <button type="submit">Create Student Account</button>
            <p class="hint">Use your name, email, password, and confirm password to create an account.</p>
          </form>
        </div>
      </div>
    </section>

    <section id="app-view" class="view hidden">
      <header class="topbar card reveal-up">
        <div>
          <p class="eyebrow">Private Student Workspace</p>
          <strong class="brand-title">NotesChecker</strong>
          <p class="muted" id="user-email"></p>
        </div>
        <div class="topbar-actions">
          <button id="open-home" class="secondary small-btn active-nav" type="button">Home</button>
          <button id="open-analysis" class="secondary small-btn" type="button">Analysis</button>
          <button id="open-dashboard" class="secondary small-btn" type="button">Dashboard</button>
          <button id="logout-button" class="secondary small-btn" type="button">Logout</button>
        </div>
      </header>

      <section id="home-page" class="page-section reveal-up">
        <section class="hero">
          <div class="card">
            <p class="eyebrow">Welcome</p>
            <h2>Study smarter with NotesChecker</h2>
            <p class="lead">Use the analysis page to submit one text note, one image note, or one PDF note. The system extracts text, compares it with NCERT chapter expectations, and builds a guided learning report.</p>
            <div class="hero-badges">
              <span>Modern student UI</span>
              <span>Light / dark mode</span>
              <span>PDF and image support</span>
              <span>Dashboard history</span>
            </div>
          </div>
          <div class="hero-card">
            <h3>Suggested study routine</h3>
            <ul>
              <li>Upload one chapter note at a time</li>
              <li>Review missing formulas and definitions</li>
              <li>Use flashcards for quick revision</li>
              <li>Track score improvements in dashboard</li>
            </ul>
          </div>
        </section>
      </section>

      <section id="analysis-page" class="page-section hidden reveal-up">
        <section class="hero">
          <div class="card">
            <p class="eyebrow">One Upload at a Time</p>
            <h2>Analyze your notes deeply</h2>
            <p class="lead">Choose exactly one mode: plain text, single image, or single PDF. If you upload image or PDF, text extraction happens first and then AI analysis begins.</p>
            <div class="hero-badges">
              <span>Topic identification</span>
              <span>Missing concepts</span>
              <span>Formulas & definitions</span>
              <span>Study recommendations</span>
            </div>
          </div>
          <div class="hero-card">
            <h3>Detailed report includes</h3>
            <ul>
              <li>Overall score out of 100</li>
              <li>Clarity, organization, readability</li>
              <li>Missing formulas and definitions</li>
              <li>Weak areas and misconceptions</li>
              <li>Flashcards and exam recommendations</li>
            </ul>
          </div>
        </section>

        <section class="grid two-col">
          <form id="notes-form" class="card form-card">
            <h2>Notes Analysis</h2>
            <div class="mode-switch" id="mode-switch">
              <button class="mode-pill active-mode" type="button" data-mode="text">Text Notes</button>
              <button class="mode-pill" type="button" data-mode="image">Image Notes</button>
              <button class="mode-pill" type="button" data-mode="pdf">PDF Notes</button>
            </div>
            <div class="grid two-col compact">
              <label>
                <span>Class</span>
                <select name="classLevel" id="classLevel" required>
                  <option value="11">Class 11</option>
                  <option value="12">Class 12</option>
                </select>
              </label>
              <label>
                <span>Subject</span>
                <select name="subject" id="subject" required></select>
              </label>
            </div>
            <label>
              <span>NCERT Chapter</span>
              <select name="chapter" id="chapter" required></select>
            </label>
            <div id="text-input-panel">
              <label>
                <span>Paste your notes</span>
                <textarea name="notesText" id="notesText" rows={14} placeholder="Write or paste one complete note set here..."></textarea>
              </label>
            </div>
            <div id="file-input-panel" class="hidden">
              <label>
                <span id="file-input-label">Upload one file</span>
                <input type="file" id="uploadFile" accept="image/*,.pdf,application/pdf" />
              </label>
              <div id="file-preview" class="image-preview hidden"></div>
              <p class="hint">Only one thing at a time: either one image or one PDF.</p>
            </div>
            <div class="form-actions">
              <button type="submit" id="analyze-button">Analyze Notes</button>
              <button type="button" id="demo-fill" class="secondary">Load Demo</button>
            </div>
            <div id="analysis-loading" class="loading-box hidden">
              <div class="loader-ring"></div>
              <div>
                <strong>Analyzing your notes...</strong>
                <p class="hint">Extraction and AI analysis are preparing a detailed study report.</p>
              </div>
            </div>
          </form>

          <section class="card" id="result-panel">
            <h2>Analysis Report</h2>
            <div id="result-empty" class="empty-state">Login and analyze one note to see your detailed report here.</div>
            <div id="result-content" class="hidden"></div>
            <div class="report-actions hidden" id="report-actions">
              <button type="button" id="download-report" class="secondary">Download Report</button>
            </div>
          </section>
        </section>
      </section>

      <section id="dashboard-page" class="page-section hidden reveal-up">
        <section class="card">
          <div class="section-head">
            <div>
              <p class="eyebrow">History Dashboard</p>
              <h2>Your analysis history</h2>
              <p>Sort by latest date or highest score and open any saved report.</p>
            </div>
            <div class="dashboard-controls">
              <select id="history-sort">
                <option value="date">Sort by Date</option>
                <option value="score">Sort by Score</option>
              </select>
              <button type="button" id="refresh-results" class="secondary">Refresh</button>
            </div>
          </div>
          <div class="dashboard-summary" id="dashboard-summary"></div>
          <div id="recent-results" class="recent-results"></div>
        </section>
      </section>

      <footer class="site-footer card reveal-up">
        <div>
          <h3>NotesChecker</h3>
          <p>AI-powered note review for students with extraction, scoring, and progress tracking.</p>
          <p class="developer-credit">Developed by <span>Prasad Gaikwad</span></p>
        </div>
        <nav class="footer-links">
          <a href="/privacy-policy">Privacy Policy</a>
          <a href="/contact-us">Contact Us</a>
          <a href="/about">About</a>
        </nav>
      </footer>
    </section>

    <script src="/static/app.js"></script>
  </main>
))

app.get('/privacy-policy', (c) => c.html(`<html><head><title>Privacy Policy - NotesChecker</title><link href="/static/style.css" rel="stylesheet" /></head><body><main class="app-shell simple-page"><section class="card"><h1>Privacy Policy</h1><p>NotesChecker stores note analysis history and uploaded note data to give students a private dashboard experience. For production, connect secure hashing, encrypted storage, and managed secrets.</p><p><a href="/">Back to home</a></p></section></main></body></html>`))
app.get('/contact-us', (c) => c.html(`<html><head><title>Contact Us - NotesChecker</title><link href="/static/style.css" rel="stylesheet" /></head><body><main class="app-shell simple-page"><section class="card"><h1>Contact Us</h1><p>Need support, feedback, or collaboration?</p><p>Email: support@noteschecker.app</p><p><a href="/">Back to home</a></p></section></main></body></html>`))
app.get('/about', (c) => c.html(`<html><head><title>About - NotesChecker</title><link href="/static/style.css" rel="stylesheet" /></head><body><main class="app-shell simple-page"><section class="card"><h1>About NotesChecker</h1><p>NotesChecker helps students understand how strong their notes are and what is missing before exams. It combines upload extraction, AI analysis, and personal history tracking.</p><p><a href="/">Back to home</a></p></section></main></body></html>`))

export default app
