module.exports = {
  apps: [
    {
      name: 'notescheker',
      script: 'npx',
      args: 'wrangler pages dev dist --ip 0.0.0.0 --port 3000 --binding OPENAI_API_KEY=local --binding OPENAI_BASE_URL=local',
      cwd: '/home/user/webapp',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
        OPENAI_API_KEY: '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',
        OPENAI_BASE_URL: 'https://api.openai.com/v1',
      },
      watch: false,
      instances: 1,
      exec_mode: 'fork',
    },
  ],
}
