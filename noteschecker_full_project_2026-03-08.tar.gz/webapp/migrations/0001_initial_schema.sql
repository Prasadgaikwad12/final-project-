CREATE TABLE IF NOT EXISTS notes_analysis (
  id TEXT PRIMARY KEY,
  student_name TEXT NOT NULL,
  class_level TEXT NOT NULL,
  subject TEXT NOT NULL,
  chapter TEXT NOT NULL,
  notes TEXT NOT NULL,
  score INTEGER NOT NULL,
  strengths_json TEXT NOT NULL,
  missing_topics_json TEXT NOT NULL,
  recommendations_json TEXT NOT NULL,
  study_plan_json TEXT NOT NULL,
  ai_summary TEXT,
  ai_missing_topics_json TEXT,
  ai_misconceptions_json TEXT,
  ai_flashcards_json TEXT,
  ai_exam_tips_json TEXT,
  word_count INTEGER NOT NULL,
  keyword_coverage INTEGER NOT NULL,
  depth_score INTEGER NOT NULL,
  clarity_score INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  class_level TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS uploads (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  extracted_text TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_notes_analysis_created_at ON notes_analysis(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_analysis_subject ON notes_analysis(subject);
CREATE INDEX IF NOT EXISTS idx_notes_analysis_class_subject ON notes_analysis(class_level, subject);
CREATE INDEX IF NOT EXISTS idx_students_email ON students(email);
CREATE INDEX IF NOT EXISTS idx_uploads_student_id ON uploads(student_id);
