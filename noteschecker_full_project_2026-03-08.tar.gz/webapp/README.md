# NotesCheker

## Project Overview
- **Name**: NotesCheker
- **Goal**: Help Class 11 and 12 students upload notes, OCR text, and receive AI-powered scoring, missing-topic analysis, and exam improvement guidance.
- **Tech Stack**: Cloudflare Pages + Hono + Vite + TypeScript + OpenAI-compatible API integration + D1-ready schema
- **Status**: Local upgraded app implemented and running in sandbox. Cloudflare production deploy still requires authentication setup.

## Completed Features
- Rebranded site from NotesChejer to **NotesCheker**
- AI-style scoring engine based on NCERT chapter keyword coverage, depth, and clarity
- Real AI integration hook using secure server-side OpenAI-compatible configuration
- Support for **Class 11 and 12**
- Support for **Physics, Chemistry, Mathematics, Biology**
- NCERT chapter catalogs included for all four subjects in both classes
- Missing-topic detection using chapter must-have concepts
- Recommendations and 3-step study plan generation
- Backend API endpoints for catalog, analysis, login, register, OCR text upload, and recent results
- Student login/register system
- OCR-ready PDF/image upload text flow
- Footer with **Developed by Prasad Gaikwad**
- Privacy Policy, Contact Us, and About pages
- Light/Dark mode toggle
- Improved animations and more attractive student-friendly UI
- D1-compatible SQL migration for persistent storage
- In-memory fallback storage when D1 is not configured locally

## Functional Entry URIs
- `GET /` — Main NotesCheker website
- `GET /privacy-policy` — Privacy policy page
- `GET /contact-us` — Contact page
- `GET /about` — About page
- `GET /api/catalog` — Returns class/subject/chapter catalog
- `GET /api/chapters?classLevel=11&subject=Physics` — Returns chapters for selected class and subject
- `POST /api/analyze` — Analyze notes and return score + AI review + study advice
  - Body params: `studentName`, `classLevel`, `subject`, `chapter`, `notes`
- `GET /api/results` — Returns recent saved analyses
- `POST /api/auth/register` — Register student
  - Body params: `name`, `email`, `password`, `classLevel`
- `POST /api/auth/login` — Login student
  - Body params: `email`, `password`
- `POST /api/ocr/upload` — Save OCR extracted text for uploaded notes
  - Body params: `studentId`, `fileName`, `fileType`, `text`
- `GET /static/app.js` — Frontend logic
- `GET /static/style.css` — Styling

## Data Architecture
- **Primary tables**:
  - `notes_analysis`
  - `students`
  - `uploads`
- **Storage**:
  - Preferred: Cloudflare D1
  - Current local fallback: in-memory arrays if D1 binding is absent
- **AI Integration**:
  - Uses secure server-side `OPENAI_API_KEY` and `OPENAI_BASE_URL`
  - Never exposed to frontend

## User Guide
1. Open the homepage.
2. Register or log in as a student.
3. Optionally upload a file and paste OCR text.
4. Select Class 11 or 12.
5. Select subject and NCERT chapter.
6. Paste notes into the notes area or use OCR text.
7. Click **Analyze Notes**.
8. Review score, strengths, missing topics, AI review, recommendations, and study plan.
9. Use recent analyses to revisit previous evaluations.

## Not Yet Fully Implemented
- Direct binary OCR extraction from uploaded PDFs/images inside Cloudflare runtime
- Secure password hashing/session tokens
- Teacher/admin dashboard
- Trend charts and chapter-wise progress graphs
- R2 file storage for original uploaded files
- Full production deployment to Cloudflare Pages

## Recommended Next Steps
1. Configure Cloudflare D1 in `wrangler.jsonc`.
2. Add secure password hashing and session/cookie auth.
3. Add external OCR service integration for direct PDF/image extraction.
4. Add analytics dashboard and chapter performance trends.
5. Deploy to Cloudflare Pages after Cloudflare auth is configured.

## Local Development
```bash
cd /home/user/webapp
npm run build
pm2 start ecosystem.config.cjs
curl http://localhost:3000
```

## Database Migration
```bash
cd /home/user/webapp
npm run db:migrate:local
```

## Deployment Notes
- **Platform target**: Cloudflare Pages
- **Wrangler config name**: `notescheker`
- **Production branch**: `main`
- Before production deploy, set up Cloudflare API key and configure `cloudflare_project_name`.
- For real AI in production, add secrets for:
  - `OPENAI_API_KEY`
  - `OPENAI_BASE_URL`
