const state = {
  catalog: null,
  currentUser: null,
  darkMode: true,
  currentMode: 'text',
  currentUploadDataUrl: '',
  currentUploadName: '',
  lastReport: null,
  activePage: 'home',
  historySort: 'date',
}

const loginView = document.getElementById('login-view')
const appView = document.getElementById('app-view')
const loginForm = document.getElementById('login-form')
const registerForm = document.getElementById('register-form')
const authFeedback = document.getElementById('auth-feedback')
const showLoginButton = document.getElementById('show-login')
const showRegisterButton = document.getElementById('show-register')
const themeToggle = document.getElementById('theme-toggle')
const notesForm = document.getElementById('notes-form')
const classSelect = document.getElementById('classLevel')
const subjectSelect = document.getElementById('subject')
const chapterSelect = document.getElementById('chapter')
const notesText = document.getElementById('notesText')
const uploadFile = document.getElementById('uploadFile')
const filePreview = document.getElementById('file-preview')
const fileInputLabel = document.getElementById('file-input-label')
const resultEmpty = document.getElementById('result-empty')
const resultContent = document.getElementById('result-content')
const reportActions = document.getElementById('report-actions')
const downloadReportButton = document.getElementById('download-report')
const analysisLoading = document.getElementById('analysis-loading')
const analyzeButton = document.getElementById('analyze-button')
const demoFillButton = document.getElementById('demo-fill')
const recentResults = document.getElementById('recent-results')
const refreshResultsButton = document.getElementById('refresh-results')
const dashboardSummary = document.getElementById('dashboard-summary')
const historySort = document.getElementById('history-sort')
const openHomeButton = document.getElementById('open-home')
const openAnalysisButton = document.getElementById('open-analysis')
const openDashboardButton = document.getElementById('open-dashboard')
const homePage = document.getElementById('home-page')
const dashboardPage = document.getElementById('dashboard-page')
const analysisPage = document.getElementById('analysis-page')
const logoutButton = document.getElementById('logout-button')
const userEmail = document.getElementById('user-email')
const modeSwitch = document.getElementById('mode-switch')
const textInputPanel = document.getElementById('text-input-panel')
const fileInputPanel = document.getElementById('file-input-panel')

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  })

  const data = await response.json()
  if (!response.ok) throw new Error(data.error || 'Request failed')
  return data
}

function applyTheme() {
  document.documentElement.dataset.theme = state.darkMode ? 'dark' : 'light'
  themeToggle.textContent = state.darkMode ? '☀️' : '🌙'
  localStorage.setItem('noteschecker-theme', state.darkMode ? 'dark' : 'light')
}

function setAuthMode(mode) {
  const showLogin = mode === 'login'
  loginForm.classList.toggle('hidden', !showLogin)
  registerForm.classList.toggle('hidden', showLogin)
  loginForm.classList.toggle('active-auth-form', showLogin)
  registerForm.classList.toggle('active-auth-form', !showLogin)
  showLoginButton.classList.toggle('active-tab', showLogin)
  showRegisterButton.classList.toggle('active-tab', !showLogin)
}

function setAppView(isLoggedIn) {
  loginView.classList.toggle('hidden', isLoggedIn)
  appView.classList.toggle('hidden', !isLoggedIn)
  if (isLoggedIn) {
    userEmail.textContent = state.currentUser?.name
      ? `${state.currentUser.name} • ${state.currentUser.email}`
      : state.currentUser?.email || ''
  }
}

function setSubjects() {
  const classLevel = classSelect.value
  const subjects = Object.keys(state.catalog?.[classLevel] || {})
  subjectSelect.innerHTML = subjects.map((subject) => `<option value="${subject}">${subject}</option>`).join('')
  setChapters()
}

function setChapters() {
  const classLevel = classSelect.value
  const subject = subjectSelect.value
  const chapters = state.catalog?.[classLevel]?.[subject] || []
  chapterSelect.innerHTML = chapters.map((chapter) => `<option value="${chapter.name}">${chapter.name}</option>`).join('')
}

function setMode(mode) {
  state.currentMode = mode
  Array.from(modeSwitch.querySelectorAll('[data-mode]')).forEach((button) => {
    button.classList.toggle('active-mode', button.dataset.mode === mode)
  })

  const useText = mode === 'text'
  textInputPanel.classList.toggle('hidden', !useText)
  fileInputPanel.classList.toggle('hidden', useText)

  if (mode === 'image') {
    fileInputLabel.textContent = 'Upload one image file'
    uploadFile.accept = 'image/*'
  } else if (mode === 'pdf') {
    fileInputLabel.textContent = 'Upload one PDF file'
    uploadFile.accept = '.pdf,application/pdf'
  }
}

function renderFilePreview() {
  if (!state.currentUploadDataUrl) {
    filePreview.classList.add('hidden')
    filePreview.innerHTML = ''
    return
  }

  filePreview.classList.remove('hidden')
  const isImage = state.currentMode === 'image'
  filePreview.innerHTML = `
    ${isImage ? `<img src="${state.currentUploadDataUrl}" alt="Uploaded note preview" />` : ''}
    <div>
      <strong>${state.currentUploadName || 'Uploaded file'}</strong>
      <p class="hint">One ${state.currentMode.toUpperCase()} file selected. This will be used for extraction and AI analysis.</p>
    </div>
  `
}

function renderProgressBar(label, value) {
  return `
    <div class="progress-card">
      <div class="progress-label-row">
        <span>${label}</span>
        <strong>${value}%</strong>
      </div>
      <div class="progress-track"><div class="progress-fill" style="width:${value}%"></div></div>
    </div>
  `
}

function renderResult(record) {
  state.lastReport = record
  const report = record.aiAnalysisResult
  resultEmpty.classList.add('hidden')
  resultContent.classList.remove('hidden')
  reportActions.classList.remove('hidden')

  resultContent.innerHTML = `
    <div class="result-top">
      <div>
        <p class="eyebrow">Class ${record.classLevel} • ${record.subject}</p>
        <h3>${record.chapter}</h3>
        <p class="muted">Input mode: ${record.inputMode.toUpperCase()} • ${new Date(record.uploadDate).toLocaleString()}</p>
      </div>
      <div class="score-circle-wrap">
        <div class="score-chip">${record.score}</div>
        <p class="muted score-caption">Overall Score</p>
      </div>
    </div>

    <div class="metrics-stack">
      ${renderProgressBar('Clarity Score', report.clarityScore)}
      ${renderProgressBar('Organization Score', report.organizationScore)}
      ${renderProgressBar('Readability Score', report.readabilityScore)}
      ${renderProgressBar('Chapter Alignment', report.chapterAlignment)}
      ${renderProgressBar('Formula Coverage', report.formulaCoverageScore)}
      ${renderProgressBar('Definition Coverage', report.definitionCoverageScore)}
      ${renderProgressBar('Exam Readiness', report.examReadiness)}
    </div>

    <div class="result-grid">
      <section class="result-section card-lite">
        <h3>Summary</h3>
        <p>${report.summary}</p>
      </section>
      <section class="result-section card-lite">
        <h3>Topic Identification</h3>
        <ul class="result-list">${(report.topicIdentification || []).map((item) => `<li>${item}</li>`).join('')}</ul>
      </section>
      <section class="result-section card-lite">
        <h3>Missing Concepts</h3>
        ${report.missingConcepts?.length ? `<ul class="result-list">${report.missingConcepts.map((item) => `<li class="missing">${item}</li>`).join('')}</ul>` : '<p class="good">No major missing concepts detected.</p>'}
      </section>
      <section class="result-section card-lite">
        <h3>Missing Formulas / Definitions</h3>
        <p><strong>Formulas:</strong></p>
        ${report.missingFormulas?.length ? `<ul class="result-list">${report.missingFormulas.map((item) => `<li>${item}</li>`).join('')}</ul>` : '<p class="good">No major formula gaps.</p>'}
        <p><strong>Definitions:</strong></p>
        ${report.missingDefinitions?.length ? `<ul class="result-list">${report.missingDefinitions.map((item) => `<li>${item}</li>`).join('')}</ul>` : '<p class="good">Definitions are reasonably covered.</p>'}
      </section>
      <section class="result-section card-lite">
        <h3>Strengths</h3>
        <ul class="result-list">${(report.strengths || []).map((item) => `<li class="good">${item}</li>`).join('')}</ul>
      </section>
      <section class="result-section card-lite">
        <h3>Weak Areas & Misconceptions</h3>
        <p><strong>Weak Areas:</strong></p>
        <ul class="result-list">${(report.weakAreas || []).map((item) => `<li>${item}</li>`).join('')}</ul>
        <p><strong>Misconceptions:</strong></p>
        <ul class="result-list">${(report.misconceptions || []).map((item) => `<li>${item}</li>`).join('')}</ul>
      </section>
      <section class="result-section card-lite">
        <h3>Suggestions</h3>
        <ul class="result-list">${(report.suggestions || []).map((item) => `<li>${item}</li>`).join('')}</ul>
      </section>
      <section class="result-section card-lite">
        <h3>Study Recommendations</h3>
        <ul class="result-list">${(report.studyRecommendations || []).map((item) => `<li>${item}</li>`).join('')}</ul>
      </section>
      <section class="result-section card-lite">
        <h3>Flashcards</h3>
        <ul class="result-list">${(report.flashcards || []).map((item) => `<li><strong>Q:</strong> ${item.question}<br/><strong>A:</strong> ${item.answer}</li>`).join('')}</ul>
      </section>
    </div>
  `
}

function buildDashboardSummary(results) {
  if (!results.length) {
    dashboardSummary.innerHTML = '<div class="empty-state">No saved reports yet. Analyze your first note to build your dashboard history.</div>'
    return
  }

  const average = Math.round(results.reduce((sum, item) => sum + item.score, 0) / results.length)
  const best = Math.max(...results.map((item) => item.score))
  const latest = new Date(results[0].uploadDate).toLocaleDateString()

  dashboardSummary.innerHTML = `
    <div class="summary-card"><strong>${results.length}</strong><span>Total Reports</span></div>
    <div class="summary-card"><strong>${average}</strong><span>Average Score</span></div>
    <div class="summary-card"><strong>${best}</strong><span>Best Score</span></div>
    <div class="summary-card"><strong>${latest}</strong><span>Latest Activity</span></div>
  `
}

function renderRecentResults(results) {
  buildDashboardSummary(results)

  if (!results.length) {
    recentResults.innerHTML = '<div class="empty-state">No analysis history available yet.</div>'
    return
  }

  recentResults.innerHTML = results.map((record) => `
    <article class="recent-card reveal-up" data-report-id="${record.id}">
      <div class="recent-card-top">
        <div>
          <strong>${record.chapter}</strong>
          <div class="recent-meta">Class ${record.classLevel} • ${record.subject} • ${record.inputMode.toUpperCase()}</div>
        </div>
        <span class="badge">${record.score}/100</span>
      </div>
      <p class="recent-meta">${new Date(record.uploadDate).toLocaleString()}</p>
      <p>${record.aiAnalysisResult?.summary || 'Detailed report available.'}</p>
      <button class="secondary small-btn open-report-button" type="button" data-report-id="${record.id}">View Details</button>
    </article>
  `).join('')

  Array.from(document.querySelectorAll('.open-report-button')).forEach((button) => {
    button.addEventListener('click', async () => {
      const reportId = button.dataset.reportId
      try {
        const data = await fetchJson(`/api/results/${reportId}`)
        renderResult(data.report)
        switchPage('analysis')
      } catch (error) {
        alert(error.message)
      }
    })
  })
}

async function loadCatalog() {
  const data = await fetchJson('/api/catalog')
  state.catalog = data.catalog
  setSubjects()
}

async function loadRecentResults() {
  const data = await fetchJson(`/api/results?sortBy=${state.historySort}`)
  renderRecentResults(data.results || [])
}

function switchPage(page) {
  state.activePage = page
  homePage.classList.toggle('hidden', page !== 'home')
  analysisPage.classList.toggle('hidden', page !== 'analysis')
  dashboardPage.classList.toggle('hidden', page !== 'dashboard')
  openHomeButton.classList.toggle('active-nav', page === 'home')
  openAnalysisButton.classList.toggle('active-nav', page === 'analysis')
  openDashboardButton.classList.toggle('active-nav', page === 'dashboard')
}

function fillDemo() {
  setMode('text')
  classSelect.value = '12'
  setSubjects()
  subjectSelect.value = 'Biology'
  setChapters()
  chapterSelect.value = 'Molecular Basis of Inheritance'
  notesText.value = 'DNA is the hereditary material in most organisms. It has a double helix structure with two antiparallel strands. Replication is semiconservative. Transcription forms RNA, and translation forms proteins with the help of ribosomes. The genetic code is triplet, degenerate, and universal. DNA packaging, replication enzymes, mRNA, tRNA, and rRNA are important in this chapter.'
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(new Error('Failed to read the selected file.'))
    reader.readAsDataURL(file)
  })
}

function setLoading(isLoading) {
  analysisLoading.classList.toggle('hidden', !isLoading)
  analyzeButton.disabled = isLoading
  analyzeButton.textContent = isLoading ? 'Processing...' : 'Analyze Notes'
}

function downloadCurrentReport() {
  if (!state.lastReport) return
  const blob = new Blob([JSON.stringify(state.lastReport, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `noteschecker-report-${state.lastReport.id}.json`
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}

async function checkSession() {
  const data = await fetchJson('/api/auth/me')
  state.currentUser = data.user
  setAppView(Boolean(state.currentUser))
  if (state.currentUser) {
    await Promise.all([loadCatalog(), loadRecentResults()])
    switchPage('home')
  }
}

showLoginButton.addEventListener('click', () => setAuthMode('login'))
showRegisterButton.addEventListener('click', () => setAuthMode('register'))

themeToggle.addEventListener('click', () => {
  state.darkMode = !state.darkMode
  applyTheme()
})

classSelect.addEventListener('change', setSubjects)
subjectSelect.addEventListener('change', setChapters)
demoFillButton.addEventListener('click', fillDemo)
refreshResultsButton.addEventListener('click', () => loadRecentResults().catch((error) => alert(error.message)))
historySort.addEventListener('change', () => {
  state.historySort = historySort.value
  loadRecentResults().catch((error) => alert(error.message))
})
openHomeButton.addEventListener('click', () => switchPage('home'))
openAnalysisButton.addEventListener('click', () => switchPage('analysis'))
openDashboardButton.addEventListener('click', () => switchPage('dashboard'))
downloadReportButton.addEventListener('click', downloadCurrentReport)
logoutButton.addEventListener('click', async () => {
  await fetchJson('/api/auth/logout', { method: 'POST', body: JSON.stringify({}) })
  state.currentUser = null
  state.lastReport = null
  setAppView(false)
  switchPage('home')
  authFeedback.textContent = 'You have logged out.'
})

modeSwitch.addEventListener('click', (event) => {
  const button = event.target.closest('[data-mode]')
  if (!button) return
  setMode(button.dataset.mode)
})

uploadFile.addEventListener('change', async () => {
  const file = uploadFile.files?.[0]
  if (!file) {
    state.currentUploadDataUrl = ''
    state.currentUploadName = ''
    renderFilePreview()
    return
  }

  if (state.currentMode === 'image' && !file.type.startsWith('image/')) {
    alert('Please choose one image file only.')
    uploadFile.value = ''
    return
  }

  if (state.currentMode === 'pdf' && file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    alert('Please choose one PDF file only.')
    uploadFile.value = ''
    return
  }

  state.currentUploadName = file.name
  state.currentUploadDataUrl = await readFileAsDataUrl(file)
  renderFilePreview()
})

registerForm.addEventListener('submit', async (event) => {
  event.preventDefault()
  try {
    const payload = Object.fromEntries(new FormData(registerForm).entries())
    await fetchJson('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    })
    authFeedback.textContent = 'Registration successful. Please login now.'
    setAuthMode('login')
    loginForm.email.value = payload.email
  } catch (error) {
    authFeedback.textContent = error.message
  }
})

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault()
  try {
    const payload = Object.fromEntries(new FormData(loginForm).entries())
    const data = await fetchJson('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    })
    state.currentUser = data.user
    authFeedback.textContent = 'Login successful.'
    setAppView(true)
    await Promise.all([loadCatalog(), loadRecentResults()])
    switchPage('home')
  } catch (error) {
    authFeedback.textContent = error.message
  }
})

notesForm.addEventListener('submit', async (event) => {
  event.preventDefault()

  try {
    setLoading(true)

    const payload = {
      classLevel: classSelect.value,
      subject: subjectSelect.value,
      chapter: chapterSelect.value,
      inputMode: state.currentMode,
      notesText: state.currentMode === 'text' ? notesText.value.trim() : '',
      uploadDataUrl: state.currentMode !== 'text' ? state.currentUploadDataUrl : '',
      fileName: state.currentMode !== 'text' ? state.currentUploadName : null,
    }

    const data = await fetchJson('/api/analyze', {
      method: 'POST',
      body: JSON.stringify(payload),
    })

    renderResult(data.analysis)
    await loadRecentResults()
    switchPage('analysis')
  } catch (error) {
    alert(error.message)
  } finally {
    setLoading(false)
  }
})

state.darkMode = (localStorage.getItem('noteschecker-theme') || 'dark') === 'dark'
applyTheme()
setAuthMode('login')
setMode('text')
switchPage('home')
checkSession().catch(() => {
  setAppView(false)
})
